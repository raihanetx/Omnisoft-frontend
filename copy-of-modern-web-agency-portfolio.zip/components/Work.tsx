import React, { useState } from 'react';

const projects = [
  {
    image: 'https://images.unsplash.com/photo-1600132806370-bf17e65e942f?q=80&w=2940&auto=format&fit=crop&ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D',
    category: 'E-commerce',
    title: 'Modern E-commerce Platform',
    description: 'A cutting-edge platform for a fashion brand, focusing on user experience and seamless checkout. We developed a custom Shopify theme and integrated a headless CMS for dynamic content management, resulting in a 40% increase in conversion rates.',
    tags: ['Next.js', 'Shopify', 'Tailwind CSS', 'GraphQL']
  },
  {
    image: 'https://images.unsplash.com/photo-1551288049-bebda4e38f71?q=80&w=2940&auto=format&fit=crop&ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D',
    category: 'SaaS',
    title: 'Analytics Dashboard',
    description: 'A data visualization tool for a tech startup, helping users make informed decisions with complex datasets. We built a highly interactive and performant dashboard using React and D3.js, capable of handling real-time data streams.',
    tags: ['React', 'D3.js', 'Node.js', 'WebSocket']
  },
  {
    image: 'https://images.unsplash.com/photo-1542744173-8e7e53415bb0?q=80&w=2940&auto=format&fit=crop&ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D',
    category: 'Corporate Website',
    title: 'Creative Agency Portfolio',
    description: 'A visually-driven portfolio site to showcase the work of a leading design agency with fluid animations. The site was built on Webflow with custom code integrations for a unique, award-winning user experience.',
    tags: ['Figma', 'Webflow', 'GSAP', 'CMS']
  },
   {
    image: 'https://images.unsplash.com/photo-1586953208448-b95a6394d123?q=80&w=2874&auto=format&fit=crop&ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D',
    category: 'Mobile App',
    title: 'Wellness & Fitness App',
    description: 'A mobile application designed to help users track their fitness goals and maintain a healthy lifestyle. Featuring personalized workout plans, progress tracking, and social sharing capabilities, built cross-platform with React Native.',
    tags: ['React Native', 'Firebase', 'GraphQL', 'iOS & Android']
  },
];

const Work: React.FC = () => {
    const [activeIndex, setActiveIndex] = useState(0);

    const handlePrev = () => {
        setActiveIndex((prevIndex) => (prevIndex === 0 ? projects.length - 1 : prevIndex - 1));
    };

    const handleNext = () => {
        setActiveIndex((prevIndex) => (prevIndex === projects.length - 1 ? 0 : prevIndex + 1));
    };

    const getCardStyle = (index: number) => {
        const offset = index - activeIndex;
        
        let transform = 'translateX(100%) scale(0.8)';
        let opacity = 0;
        let zIndex = 0;

        if (offset === 0) { // Active card
            transform = 'translateX(0) scale(1)';
            opacity = 1;
            zIndex = 30;
        } else if (offset === 1) { // Next card
            transform = 'translateX(50%) scale(0.9)';
            opacity = 0.7;
            zIndex = 20;
        } else if (offset === 2) { // Card after next
            transform = 'translateX(100%) scale(0.8)';
            opacity = 0.4;
            zIndex = 10;
        } else if (offset === -1) { // Previous card, now moving out
            transform = 'translateX(-50%) scale(0.9)';
            opacity = 0;
            zIndex = 20;
        } else { // All other cards are hidden
             transform = offset > 0 ? 'translateX(100%) scale(0.8)' : 'translateX(-100%) scale(0.8)';
             opacity = 0;
             zIndex = 0;
        }

        return {
            transform,
            opacity,
            zIndex,
            transition: 'all 0.7s cubic-bezier(0.25, 1, 0.5, 1)',
        };
    };

    return (
        <section id="work" className="py-20 md:py-28 bg-black overflow-hidden">
            <div className="container mx-auto px-6">
                <div className="text-center mb-16">
                     <h2 className="text-3xl sm:text-4xl md:text-5xl font-black text-white mb-4">Our Creative Showcase</h2>
                     <p className="max-w-2xl mx-auto text-base sm:text-lg text-gray-400">
                        Explore a curated selection of our most innovative and impactful projects.
                     </p>
                </div>

                <div className="relative h-[600px] sm:h-[550px] md:h-[500px] w-full max-w-4xl mx-auto" style={{ perspective: '1000px' }}>
                    {projects.map((project, index) => (
                        <div
                            key={project.title}
                            className="absolute inset-0 w-full h-full"
                            style={getCardStyle(index)}
                        >
                            <div className="w-full h-full rounded-2xl overflow-hidden shadow-2xl shadow-black/50 bg-gray-900 border border-gray-800 flex flex-col md:flex-row">
                                <div className="w-full md:w-3/5 h-1/2 md:h-full relative">
                                    <img src={project.image} alt={project.title} className="w-full h-full object-cover"/>
                                    <div className="absolute inset-0 bg-gradient-to-t from-gray-900 via-gray-900/50 to-transparent md:bg-gradient-to-r md:from-gray-900 md:to-transparent"></div>
                                </div>
                                <div className="w-full md:w-2/5 h-1/2 md:h-full p-6 md:p-8 flex flex-col justify-center">
                                    <div>
                                        <p className="text-sm font-semibold text-gray-400 mb-2">{project.category}</p>
                                        <h3 className="text-2xl lg:text-3xl font-bold text-white mb-4">{project.title}</h3>
                                        <p className="text-gray-400 leading-relaxed mb-6 text-sm overflow-hidden" style={{ display: '-webkit-box', WebkitLineClamp: 4, WebkitBoxOrient: 'vertical' }}>{project.description}</p>
                                        <div className="flex flex-wrap gap-2">
                                            {project.tags.map(tag => (
                                                <span key={tag} className="bg-gray-800 text-gray-200 px-3 py-1 rounded-full text-xs font-medium">{tag}</span>
                                            ))}
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    ))}
                </div>

                <div className="flex justify-center items-center mt-12 gap-4">
                    <button
                        onClick={handlePrev}
                        className="bg-gray-800/80 text-white hover:bg-gray-800 transition-all duration-300 rounded-full w-12 h-12 shadow-lg backdrop-blur-sm disabled:opacity-50 flex items-center justify-center"
                        aria-label="Previous Project"
                    >
                        <i className="fas fa-chevron-left"></i>
                    </button>
                    <button
                        onClick={handleNext}
                        className="bg-gray-800/80 text-white hover:bg-gray-800 transition-all duration-300 rounded-full w-12 h-12 shadow-lg backdrop-blur-sm disabled:opacity-50 flex items-center justify-center"
                        aria-label="Next Project"
                    >
                        <i className="fas fa-chevron-right"></i>
                    </button>
                </div>
            </div>
        </section>
    );
};

export default Work;