import React from 'react';

const stats = [
  { value: '50+', label: 'Projects Delivered' },
  { value: '98%', label: 'Client Satisfaction' },
  { value: '10+', label: 'Years of Experience' },
  { value: '1M+', label: 'Users Reached' },
];

const Achievements: React.FC = () => {
  return (
    <section id="achievements" className="py-20 md:py-28 bg-[#1a1423]">
      <div className="container mx-auto px-6">
        <div className="grid grid-cols-2 md:grid-cols-4 gap-8 text-center">
          {stats.map((stat, index) => (
            <div key={index}>
              <h3 className="text-4xl sm:text-5xl md:text-6xl font-black text-[#F4EDFF] mb-2">
                {stat.value}
              </h3>
              <p className="text-[#BBA3DB] font-medium">{stat.label}</p>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
};

export default Achievements;