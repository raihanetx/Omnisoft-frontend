import React, { useState, useEffect } from 'react';
import { LogoIcon } from './icons/LogoIcon';

const Header: React.FC = () => {
  const [isScrolled, setIsScrolled] = useState(false);
  const [isMenuOpen, setIsMenuOpen] = useState(false);

  useEffect(() => {
    const handleScroll = () => {
      const offset = window.scrollY;
      if (offset > 20) {
        setIsScrolled(true);
      } else {
        setIsScrolled(false);
      }
    };

    window.addEventListener('scroll', handleScroll);

    return () => {
      window.removeEventListener('scroll', handleScroll);
    };
  }, []);

  useEffect(() => {
    if (isMenuOpen) {
      document.body.style.overflow = 'hidden';
    } else {
      document.body.style.overflow = '';
    }
  }, [isMenuOpen]);

  const navLinks = ['About', 'Services', 'Work', 'Process', 'Team', 'Testimonials', 'FAQ'];

  return (
    <>
      <header
        className={`fixed top-0 left-0 right-0 z-50 transition-all duration-300 ease-in-out ${
          isScrolled || isMenuOpen ? 'bg-black/80 shadow-md backdrop-blur-lg border-b border-gray-800' : 'bg-transparent'
        }`}
      >
        <div className="container mx-auto px-6 py-4">
          <div className="flex justify-between items-center">
            <a href="#" className="flex items-center space-x-2 text-white">
              <LogoIcon className="h-8 w-8 text-white" />
              <span className="font-bold text-xl tracking-tight">Stellar</span>
            </a>

            <nav className="hidden md:flex items-center space-x-8">
              {navLinks.map((link) => (
                <a
                  key={link}
                  href={`#${link.toLowerCase()}`}
                  className="text-gray-300 hover:text-white transition-colors duration-200 font-medium"
                >
                  {link}
                </a>
              ))}
            </nav>

            <a
              href="#contact"
              className="hidden md:inline-block bg-gradient-to-r from-gray-200 to-gray-400 text-black font-semibold px-5 py-2.5 rounded-lg hover:opacity-90 transition-all duration-300"
            >
              Schedule a Call
            </a>
            
            <button className="md:hidden text-gray-300 z-50" onClick={() => setIsMenuOpen(!isMenuOpen)} aria-label="Toggle menu">
               <i className={`fas ${isMenuOpen ? 'fa-times' : 'fa-bars'} text-2xl transition-transform duration-300`}></i>
            </button>
          </div>
        </div>
      </header>

      {/* Mobile Menu Overlay */}
      <div 
        className={`md:hidden fixed inset-0 z-40 bg-black/95 backdrop-blur-lg transition-opacity duration-300 ${isMenuOpen ? 'opacity-100' : 'opacity-0 pointer-events-none'}`}
      >
        <div className="container mx-auto px-6 pt-24 pb-8 flex flex-col h-full">
            <nav className="flex flex-col items-center justify-center flex-grow space-y-8">
              {navLinks.map((link) => (
                <a
                  key={link}
                  href={`#${link.toLowerCase()}`}
                  onClick={() => setIsMenuOpen(false)}
                  className="text-gray-300 hover:text-white text-3xl font-bold transition-colors duration-200"
                >
                  {link}
                </a>
              ))}
            </nav>
            <a
              href="#contact"
              onClick={() => setIsMenuOpen(false)}
              className="w-full text-center bg-gradient-to-r from-gray-200 to-gray-400 text-black font-semibold px-5 py-4 rounded-lg hover:opacity-90 transition-all duration-300 mt-8"
            >
              Schedule a Call
            </a>
          </div>
      </div>
    </>
  );
};

export default Header;