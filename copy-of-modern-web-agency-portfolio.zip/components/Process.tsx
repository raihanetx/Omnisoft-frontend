import React from 'react';

const steps = [
  {
    number: '01',
    title: 'Discovery & Strategy',
    description: 'We start by understanding your business, goals, and audience to create a comprehensive project roadmap.',
  },
  {
    number: '02',
    title: 'Design & Prototyping',
    description: 'We craft wireframes and high-fidelity mockups, focusing on user experience and visual design.',
  },
  {
    number: '03',
    title: 'Development & Testing',
    description: 'Our team brings the designs to life with clean, efficient code, followed by rigorous testing.',
  },
  {
    number: '04',
    title: 'Launch & Optimization',
    description: 'We deploy your project and monitor its performance, making data-driven optimizations for growth.',
  },
];

const Process: React.FC = () => {
  return (
    <section id="process" className="py-20 md:py-28 bg-black">
      <div className="container mx-auto px-6">
        <div className="text-center mb-16">
          <h2 className="text-3xl sm:text-4xl md:text-5xl font-black text-white mb-4">Our Proven Process</h2>
          <p className="max-w-2xl mx-auto text-base sm:text-lg text-gray-400">
            A streamlined journey from idea to impact, ensuring quality and transparency at every stage.
          </p>
        </div>
        <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-8">
          {steps.map((step) => (
            <div key={step.number} className="relative p-8 bg-gray-900 rounded-lg overflow-hidden">
              <div 
                className="absolute -top-4 -left-4 text-8xl font-black text-gray-800/50 select-none"
                aria-hidden="true"
              >
                {step.number}
              </div>
              <div className="relative">
                <h3 className="text-2xl font-bold text-white mb-3 mt-4">{step.title}</h3>
                <p className="text-gray-400">{step.description}</p>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
};

export default Process;