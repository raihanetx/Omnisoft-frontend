import React, { useRef } from 'react';

const services = [
  {
    icon: <i className="fas fa-compass"></i>,
    title: 'Brand Strategy',
    description: 'We define your brand’s voice and positioning to create a strong foundation for your digital presence.',
  },
  {
    icon: <i className="fas fa-palette"></i>,
    title: 'UI/UX Design',
    description: 'Crafting intuitive and beautiful user interfaces that provide an exceptional user experience, ensuring your users are engaged and delighted.',
  },
  {
    icon: <i className="fas fa-code"></i>,
    title: 'Web Development',
    description: 'Building responsive, high-performance websites and applications using the most modern technologies.',
  },
  {
    icon: <i className="fas fa-shopping-cart"></i>,
    title: 'E-commerce Solutions',
    description: 'Developing scalable and secure online stores that drive sales.',
  },
  {
    icon: <i className="fas fa-chart-pie"></i>,
    title: 'SEO & Marketing',
    description: 'Optimizing your site for search engines and running campaigns to drive sustained traffic and growth.',
  },
  {
    icon: <i className="fas fa-server"></i>,
    title: 'Cloud & DevOps',
    description: 'Automating deployment and scaling your infrastructure for maximum reliability and efficiency.',
  }
];

const gridLayoutClasses = [
  'lg:col-span-3', // Brand Strategy
  'lg:col-span-2 lg:row-span-2', // UI/UX Design
  'lg:col-span-1', // Web Development
  'lg:col-span-2', // E-commerce
  'lg:col-span-3', // SEO & Marketing
  'lg:col-span-2', // Cloud & DevOps
];

const ServiceCard: React.FC<{ service: typeof services[0], className?: string }> = ({ service, className }) => {
  const cardRef = useRef<HTMLDivElement>(null);

  const handleMouseMove = (e: React.MouseEvent<HTMLDivElement>) => {
    const card = cardRef.current;
    if (!card) return;

    const rect = card.getBoundingClientRect();
    const x = e.clientX - rect.left;
    const y = e.clientY - rect.top;
    const width = rect.width;
    const height = rect.height;

    const rotateX = (y / height - 0.5) * -15;
    const rotateY = (x / width - 0.5) * 15;

    card.style.transform = `perspective(1000px) rotateX(${rotateX}deg) rotateY(${rotateY}deg) scale3d(1.05, 1.05, 1.05)`;
    card.style.setProperty('--mouse-x', `${x}px`);
    card.style.setProperty('--mouse-y', `${y}px`);
  };

  const handleMouseLeave = () => {
    const card = cardRef.current;
    if (!card) return;
    card.style.transform = 'perspective(1000px) rotateX(0deg) rotateY(0deg) scale3d(1, 1, 1)';
  };

  return (
    <div
      ref={cardRef}
      onMouseMove={handleMouseMove}
      onMouseLeave={handleMouseLeave}
      className={`group relative rounded-2xl bg-gradient-to-br from-gray-900 to-gray-950 p-8 text-left transition-all duration-300 ease-out border border-gray-800 backdrop-blur-sm shadow-2xl shadow-black/20 ${className}`}
      style={{ transformStyle: 'preserve-3d', transition: 'transform 0.2s ease-out' }}
    >
      {/* Glare effect */}
      <div 
        className="pointer-events-none absolute -inset-px rounded-2xl opacity-0 transition-opacity duration-300 group-hover:opacity-100"
        style={{ background: 'radial-gradient(400px circle at var(--mouse-x) var(--mouse-y), rgba(255, 255, 255, 0.08), transparent 40%)' }} 
      />
      
      <div className="relative z-10 flex flex-col h-full" style={{ transform: 'translateZ(40px)' }}>
        <div className="mb-6">
          <div className="w-16 h-16 rounded-xl flex items-center justify-center bg-gray-800/80 border border-gray-700 text-3xl text-gray-400 transition-all duration-300 group-hover:bg-gray-700/60 group-hover:text-white group-hover:border-gray-600">
            {service.icon}
          </div>
        </div>
        <div className="flex-grow">
          <h3 className="text-xl font-bold text-white mb-2">{service.title}</h3>
          <p className="text-gray-400 leading-relaxed">{service.description}</p>
        </div>
      </div>
    </div>
  );
};


const Services: React.FC = () => {
  return (
    <section id="services" className="relative py-20 md:py-28 bg-black overflow-hidden">
        {/* Background Elements */}
        <div className={`absolute inset-0 z-0 opacity-10 bg-[url("data:image/svg+xml,%3csvg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 32 32' width='32' height='32' fill='none' stroke='rgb(255 255 255 / 0.1)'%3e%3cpath d='M0 .5H31.5V32'/%3e%3c/svg%3e")]`}></div>
        <div className="absolute -top-1/4 left-0 w-96 h-96 bg-purple-900/30 rounded-full blur-3xl opacity-50 animate-float-reverse -z-10"></div>
        <div className="absolute -bottom-1/4 right-0 w-96 h-96 bg-cyan-900/30 rounded-full blur-3xl opacity-50 animate-float -z-10"></div>

      <div className="container mx-auto px-6 text-center relative z-10">
        <h2 className="text-3xl sm:text-4xl md:text-5xl font-black text-white mb-4">What We Offer</h2>
        <p className="max-w-2xl mx-auto text-base sm:text-lg text-gray-400 mb-16">
          We provide a full spectrum of services to bring your digital vision to life, from initial strategy to final launch.
        </p>
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-5 gap-8">
          {services.map((service, index) => (
            <ServiceCard 
              key={index} 
              service={service}
              className={gridLayoutClasses[index]} 
            />
          ))}
        </div>
      </div>
    </section>
  );
};

export default Services;