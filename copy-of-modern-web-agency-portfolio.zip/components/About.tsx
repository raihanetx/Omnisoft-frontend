import React from 'react';

const features = [
  {
    icon: <i className="fas fa-bullseye text-3xl text-gray-300"></i>,
    title: 'Brand-Centric Approach',
    description: 'We dive deep into your brand identity to create a digital presence that is a true reflection of your values.',
  },
  {
    icon: <i className="fas fa-chart-line text-3xl text-gray-300"></i>,
    title: 'Results-Driven Solutions',
    description: 'Our strategies are focused on achieving measurable outcomes, ensuring a high return on your investment.',
  },
  {
    icon: <i className="fas fa-handshake text-3xl text-gray-300"></i>,
    title: 'Collaborative Partnership',
    description: 'We work with you, not just for you. Your insights are crucial to our shared success.',
  },
  {
    icon: <i className="fas fa-user-shield text-3xl text-gray-300"></i>,
    title: 'End-to-End Support',
    description: 'From initial concept to post-launch maintenance, we provide comprehensive support at every step.',
  },
];


const About: React.FC = () => {
  return (
    <section id="about" className="py-20 md:py-28 bg-black">
      <div className="container mx-auto px-6">
        <div className="grid lg:grid-cols-2 gap-12 lg:gap-16 items-center">
          <div className="relative">
             <div className="absolute -inset-2 bg-gray-700 rounded-2xl blur-xl opacity-50"></div>
            <img 
              src="https://images.unsplash.com/photo-1557804506-669a67965ba0?q=80&w=2874&auto=format&fit=crop&ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D" 
              alt="A team of professionals collaborating in a modern office"
              className="relative rounded-2xl shadow-2xl object-cover w-full h-full"
            />
          </div>
          <div className="space-y-6">
            <h2 className="text-3xl sm:text-4xl md:text-5xl font-black text-white leading-tight">
              A Digital Partner,
              <br />
              Not Just a Provider.
            </h2>
            <p className="text-base sm:text-lg text-gray-400 leading-relaxed">
              We believe that true success comes from a deep, collaborative partnership. We go beyond being just a service provider to become an integral part of your team, dedicated to your growth.
            </p>
            <div className="grid sm:grid-cols-2 gap-6 pt-4">
              {features.map((feature, index) => (
                 <div key={index} className="bg-gray-900 p-6 rounded-lg border border-gray-800 hover:border-gray-700 hover:-translate-y-1 transition-all duration-300">
                    <div className="bg-gray-800 inline-flex items-center justify-center p-3 rounded-md mb-4 h-14 w-14">
                        {feature.icon}
                    </div>
                    <h3 className="text-lg font-bold text-white mb-1">{feature.title}</h3>
                    <p className="text-gray-400 text-sm leading-relaxed">{feature.description}</p>
                 </div>
              ))}
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};

export default About;